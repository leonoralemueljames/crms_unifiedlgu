<?php
include('../connection.php');
include('../session/check_session.php');

require __DIR__ . "/vendor/autoload.php";

use Dompdf\Dompdf;
use Dompdf\Options;

$fullname1 = isset($_SESSION['name']) ? htmlspecialchars($_SESSION['name']) : 'Guest';
$fullname = strtoupper($fullname1);

$course = $_SESSION['course'];



//$html = '<h1 style="color: green">Example</h1>';
//$html .= "Hello <em>$name</em>";
//$html .= '<img src="example.png">';
//$html .= "Quantity: $quantity";

/**
 * Set the Dompdf options
 */
$options = new Options;
$options->setChroot(__DIR__);
$options->setIsRemoteEnabled(true);

$dompdf = new Dompdf($options);

/**
 * Set the paper size and orientation
 */
$dompdf->setPaper("A4", "landscape");

/**
 * Load the HTML and replace placeholders with values from the form
 */
$html = file_get_contents("template.html");

$html = str_replace(["{{ name }}", "{{ course }}"], [$fullname, $course], $html);

$dompdf->loadHtml($html);
//$dompdf->loadHtmlFile("template.html");

/**
 * Create the PDF and set attributes
 */
$dompdf->render();

$dompdf->addInfo("Title", "Course Certificate PDF"); // "add_info" in earlier versions of Dompdf

/**
 * Send the PDF to the browser
 */
ob_end_clean();

$dompdf->stream("course_certificate.pdf", ["Attachment" => 0]);

/**
 * Save the PDF file locally
 */
$output = $dompdf->output();
file_put_contents("file.pdf", $output);

	
?>